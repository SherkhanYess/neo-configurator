var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var update_lead_exports = {};
__export(update_lead_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(update_lead_exports);
const handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  const AMO_DOMAIN = process.env.AMO_DOMAIN;
  const AMO_LONG_TOKEN = process.env.AMO_LONG_TOKEN;
  if (!AMO_DOMAIN || !AMO_LONG_TOKEN) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Server misconfigured" }) };
  }
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  const { leadId, stageId, note } = body;
  if (!leadId || !stageId) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "leadId and stageId are required" }) };
  }
  const amoBase = `https://${AMO_DOMAIN}.amocrm.ru/api/v4`;
  const amoHdrs = {
    "Authorization": `Bearer ${AMO_LONG_TOKEN}`,
    "Content-Type": "application/json"
  };
  try {
    const res = await fetch(`${amoBase}/leads/${leadId}`, {
      method: "PATCH",
      headers: amoHdrs,
      body: JSON.stringify({ status_id: stageId })
    });
    if (!res.ok) {
      const err = await res.text();
      console.error("amoCRM update-lead error:", err);
      return { statusCode: 502, headers, body: JSON.stringify({ error: "amoCRM update failed", detail: err }) };
    }
    if (note) {
      await fetch(`${amoBase}/leads/${leadId}/notes`, {
        method: "POST",
        headers: amoHdrs,
        body: JSON.stringify([{ note_type: "common", params: { text: note } }])
      }).catch((e) => console.warn("note failed:", e));
    }
    return { statusCode: 200, headers, body: JSON.stringify({ ok: true, leadId, stageId }) };
  } catch (err) {
    console.error("update-lead error:", err);
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Internal error", detail: String(err) }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
