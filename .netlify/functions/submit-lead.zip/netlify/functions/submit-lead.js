var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var submit_lead_exports = {};
__export(submit_lead_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(submit_lead_exports);
const AMO_FIELDS = {
  // «Город заказа» — field 409769
  city: {
    id: 409769,
    enums: {
      "\u0410\u043B\u043C\u0430\u0442\u044B": 268607,
      "\u0410\u0441\u0442\u0430\u043D\u0430": 268609,
      "\u0428\u044B\u043C\u043A\u0435\u043D\u0442": 268611,
      "\u0410\u043A\u0442\u043E\u0431\u0435": 268613,
      "\u0410\u043A\u0442\u0430\u0443": 268615,
      "\u041A\u0430\u0440\u0430\u0433\u0430\u043D\u0434\u044B": 284341,
      "\u0410\u0442\u044B\u0440\u0430\u0443": 284343,
      "\u0414\u0440\u0443\u0433\u043E\u0439 \u0433\u043E\u0440\u043E\u0434": 284345
    }
  },
  // «Повод покупки» — field 420033
  occasion: {
    id: 420033,
    enums: {
      "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435": 284327,
      "\u041F\u043E\u0434\u0430\u0440\u043E\u043A": 284329,
      "\u0414\u043B\u044F \u0441\u0435\u0431\u044F": 284331
    }
  },
  // «Когда нужно» — field 420035
  timing: {
    id: 420035,
    enums: {
      "\u0414\u043E 5-\u0434\u043D\u0435\u0439": 284333,
      "\u0412 \u0442\u0435\u0447\u0435\u043D\u0438\u0439 10 \u0434\u043D\u0435\u0439": 284335,
      "\u0412 \u0442\u0435\u0447\u0435\u043D\u0438\u0439 \u043C\u0435\u0441\u044F\u0446\u0430": 284337,
      "\u0411\u043E\u043B\u044C\u0448\u0435 \u043C\u0435\u0441\u044F\u0446\u0430": 284339,
      // Landing aliases
      "\u0412 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u043D\u0435\u0434\u0435\u043B\u0438": 284333,
      "\u0412 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u043C\u0435\u0441\u044F\u0446\u0430": 284337,
      "\u041F\u043E\u043A\u0430 \u043F\u0440\u0438\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u044E\u0441\u044C": 284339,
      "\u041F\u043E\u043A\u0430 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0438\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u044E\u0441\u044C": 284339,
      // Custom month values
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u042F\u043D\u0432\u0430\u0440\u044C": 289825,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u0424\u0435\u0432\u0440\u0430\u043B\u044C": 289827,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u041C\u0430\u0440\u0442": 289829,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u0410\u043F\u0440\u0435\u043B\u044C": 289831,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u041C\u0430\u0439": 289833,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u0418\u044E\u043D\u044C": 289835,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u0418\u044E\u043B\u044C": 289837,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u0410\u0432\u0433\u0443\u0441\u0442": 289839,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u0421\u0435\u043D\u0442\u044F\u0431\u0440\u044C": 289841,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u041E\u043A\u0442\u044F\u0431\u0440\u044C": 289843,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u041D\u043E\u044F\u0431\u0440\u044C": 289845,
      "\u0421\u0432\u043E\u044F \u0434\u0430\u0442\u0430: \u0414\u0435\u043A\u0430\u0431\u0440\u044C": 289847
    }
  },
  // UTM_ID — field 417935 (textarea)
  utmId: { id: 417935 },
  // TRANID — field 417929 (textarea)
  tranId: { id: 417929 },
  // UTM tracking_data fields
  utm_source: { id: 61411 },
  utm_medium: { id: 61407 },
  utm_campaign: { id: 61409 },
  utm_content: { id: 61405 },
  utm_term: { id: 61413 }
};
function buildCustomFields({ city, occasion, timing, utm = {} }) {
  const result = [];
  const addEnum = (fieldId, enumId) => {
    if (enumId) result.push({ field_id: fieldId, values: [{ enum_id: enumId }] });
  };
  const addText = (fieldId, value) => {
    if (value) result.push({ field_id: fieldId, values: [{ value: String(value) }] });
  };
  addEnum(AMO_FIELDS.city.id, AMO_FIELDS.city.enums[city]);
  addEnum(AMO_FIELDS.occasion.id, AMO_FIELDS.occasion.enums[occasion]);
  addEnum(AMO_FIELDS.timing.id, AMO_FIELDS.timing.enums[timing]);
  addText(AMO_FIELDS.utmId.id, utm.utm_source);
  addText(AMO_FIELDS.tranId.id, utm.utm_campaign);
  addText(AMO_FIELDS.utm_source.id, utm.utm_source);
  addText(AMO_FIELDS.utm_medium.id, utm.utm_medium);
  addText(AMO_FIELDS.utm_campaign.id, utm.utm_campaign);
  addText(AMO_FIELDS.utm_content.id, utm.utm_content);
  addText(AMO_FIELDS.utm_term.id, utm.utm_term);
  return result;
}
const handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  const AMO_DOMAIN = process.env.AMO_DOMAIN;
  const AMO_LONG_TOKEN = process.env.AMO_LONG_TOKEN;
  if (!AMO_DOMAIN || !AMO_LONG_TOKEN) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Server misconfigured" }) };
  }
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  const { name, city, occasion, timing, estimatedPrice, config = {}, configUrl = "", utm = {}, senderUtm = {}, configLinesWA = "", preCapture = false } = body;
  const effectiveUtm = senderUtm?.utm_source ? { ...senderUtm, utm_term: "share" } : utm;
  const rawPhone = String(body.phone || "").replace(/\D/g, "");
  const phone = rawPhone.startsWith("7") ? `+${rawPhone}` : rawPhone.startsWith("8") ? `+7${rawPhone.slice(1)}` : `+${rawPhone}`;
  if (!name || !phone) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "name and phone are required" }) };
  }
  const amoBase = `https://${AMO_DOMAIN}.amocrm.ru/api/v4`;
  const amoHdrs = {
    "Authorization": `Bearer ${AMO_LONG_TOKEN}`,
    "Content-Type": "application/json"
  };
  try {
    const contactRes = await fetch(`${amoBase}/contacts`, {
      method: "POST",
      headers: amoHdrs,
      body: JSON.stringify([{
        name,
        custom_fields_values: [{
          field_code: "PHONE",
          values: [{ value: phone, enum_code: "WORK" }]
        }]
      }])
    });
    if (!contactRes.ok) {
      const err = await contactRes.text();
      console.error("amoCRM contact error:", err);
      return { statusCode: 502, headers, body: JSON.stringify({ error: "amoCRM contact failed", detail: err }) };
    }
    const contactData = await contactRes.json();
    const contactId = contactData?._embedded?.contacts?.[0]?.id;
    const configLines = [
      config.shapeLabel && `\u041E\u0433\u0440\u0430\u043D\u043A\u0430: ${config.shapeLabel}`,
      config.shankLabel && `\u0428\u0438\u043D\u043A\u0430: ${config.shankLabel}`,
      config.castLabel && `\u041A\u0430\u0441\u0442: ${config.castLabel}`,
      config.carat && `\u041A\u0430\u0440\u0430\u0442\u043D\u043E\u0441\u0442\u044C: ${config.carat} \u043A\u0430\u0440`,
      config.gem1Label && `\u0426\u0435\u043D\u0442\u0440. \u0431\u0440\u0438\u043B\u043B\u0438\u0430\u043D\u0442: ${config.gem1Label}`,
      config.gem2Label && `\u0420\u043E\u0441\u0441\u044B\u043F\u044C: ${config.gem2Label}`,
      config.purity && `\u041F\u0440\u043E\u0431\u0430: ${config.purity}`,
      config.metalLabel && `\u041C\u0435\u0442\u0430\u043B\u043B: ${config.metalLabel}`
    ].filter(Boolean).join("\n");
    const noteText = [
      "\u{1F48D} \u041A\u043E\u043D\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044F \u0443\u043A\u0440\u0430\u0448\u0435\u043D\u0438\u044F:",
      configLines || "\u2014",
      configUrl ? `
\u{1F517} \u0421\u0441\u044B\u043B\u043A\u0430: ${configUrl}` : ""
    ].filter(Boolean).join("\n").trim();
    const leadName = ["\u041A\u043E\u043B\u044C\u0446\u043E", config.shapeLabel, config.carat ? `${config.carat}\u043A\u0430\u0440` : null, "\u2014", name].filter(Boolean).join(" ");
    const customFields = buildCustomFields({ city, occasion, timing, utm: effectiveUtm });
    const leadRes = await fetch(`${amoBase}/leads`, {
      method: "POST",
      headers: amoHdrs,
      body: JSON.stringify([{
        name: leadName,
        custom_fields_values: customFields,
        ...contactId ? { _embedded: { contacts: [{ id: contactId }] } } : {}
      }])
    });
    if (!leadRes.ok) {
      const err = await leadRes.text();
      console.error("amoCRM lead error:", err);
      return { statusCode: 502, headers, body: JSON.stringify({ error: "amoCRM lead failed", detail: err }) };
    }
    const leadData = await leadRes.json();
    const leadId = leadData?._embedded?.leads?.[0]?.id;
    if (leadId && noteText) {
      await fetch(`${amoBase}/leads/${leadId}/notes`, {
        method: "POST",
        headers: amoHdrs,
        body: JSON.stringify([{ note_type: "common", params: { text: noteText } }])
      }).catch((e) => console.warn("note failed:", e));
    }
    if (preCapture) {
      return { statusCode: 200, headers, body: JSON.stringify({ ok: true, leadId, contactId, preCapture: true }) };
    }
    const KELESU_KEY = process.env.KELESU_API_KEY;
    const KELESU_CHANNEL_ID = process.env.KELESU_CHANNEL_ID;
    if (KELESU_KEY && KELESU_CHANNEL_ID) {
      const priceStr = estimatedPrice ? `${Number(estimatedPrice).toLocaleString("ru-KZ")} \u20B8` : "\u0443\u0442\u043E\u0447\u043D\u044F\u0435\u0442\u0441\u044F";
      const phoneDigits = phone.replace(/^\+/, "");
      try {
        const res = await fetch(`https://api.kelesu.kz/api/v1/waba/channels/${KELESU_CHANNEL_ID}/templates/send-to-phone`, {
          method: "POST",
          headers: {
            "X-API-Key": KELESU_KEY,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            phone_number: phoneDigits,
            template_name: "constructor_final_price",
            components: [
              {
                type: "body",
                parameters: [
                  { type: "text", text: name },
                  { type: "text", text: config.shapeLabel || "\u2014" },
                  { type: "text", text: config.shankLabel || "\u2014" },
                  { type: "text", text: config.castLabel || "\u2014" },
                  { type: "text", text: config.carat ? String(config.carat) : "\u2014" },
                  { type: "text", text: config.gem1Label || "\u2014" },
                  { type: "text", text: config.purity || "\u2014" },
                  { type: "text", text: config.metalLabel || "\u2014" },
                  { type: "text", text: priceStr }
                ]
              }
            ]
          })
        });
        const kelesuBody = await res.text();
        return { statusCode: 200, headers, body: JSON.stringify({ ok: true, leadId, contactId, kelesu: res.status, kelesuBody }) };
      } catch (e) {
        return { statusCode: 200, headers, body: JSON.stringify({ ok: true, leadId, contactId, kelesuError: String(e) }) };
      }
    }
    return { statusCode: 200, headers, body: JSON.stringify({ ok: true, leadId, contactId }) };
  } catch (err) {
    console.error("submit-lead error:", err);
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Internal error", detail: String(err) }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
