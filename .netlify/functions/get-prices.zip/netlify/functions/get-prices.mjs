
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/get-prices.js
import { getStore } from "@netlify/blobs";
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Content-Type": "application/json"
};
var get_prices_default = async (req, context) => {
  if (req.method === "OPTIONS") {
    return new Response("", { status: 204, headers: CORS });
  }
  try {
    const store = getStore({ name: "nd-prices", context });
    const raw = await store.get("config");
    const prices = raw ? JSON.parse(raw) : null;
    return new Response(JSON.stringify(prices ?? getDefaultPrices()), { status: 200, headers: CORS });
  } catch (err) {
    console.warn("get-prices blob error (returning defaults):", err);
    return new Response(JSON.stringify(getDefaultPrices()), { status: 200, headers: CORS });
  }
};
var config = { path: "/api/get-prices" };
function getDefaultPrices() {
  return {
    baseByShank: {
      "Neo": 2e5,
      "Neo Luxe": 25e4,
      "Sirius": 22e4,
      "Sirius Luxe": 28e4,
      "Bezel": 23e4
    },
    casts: {
      halo: 3e4,
      bezel: 2e4
    },
    caratPrice: 2e5,
    // per carat ABOVE 1
    purity750surcharge: 2e4,
    fancyColorSurcharge: 1e5,
    // per carat, central diamond only
    scatterFancySurcharge: 15e4
    // flat, per scatter zone (россыпь / хало)
  };
}
export {
  config,
  get_prices_default as default
};
