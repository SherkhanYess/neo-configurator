
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/set-prices.js
import { getStore } from "@netlify/blobs";
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
var set_prices_default = async (req, context) => {
  if (req.method === "OPTIONS") {
    return new Response("", { status: 204, headers: CORS });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: CORS });
  }
  const ADMIN_TOKEN = process.env.ADMIN_TOKEN;
  const authHeader = req.headers.get("authorization") ?? "";
  const token = authHeader.replace("Bearer ", "").trim();
  if (!ADMIN_TOKEN || token !== ADMIN_TOKEN) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: CORS });
  }
  let prices;
  try {
    prices = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: CORS });
  }
  if (!prices || typeof prices !== "object" || Array.isArray(prices)) {
    return new Response(JSON.stringify({ error: "Invalid prices object" }), { status: 400, headers: CORS });
  }
  try {
    const store = getStore({ name: "nd-prices", context });
    await store.set("config", JSON.stringify(prices));
    return new Response(JSON.stringify({ ok: true }), { status: 200, headers: CORS });
  } catch (err) {
    console.error("set-prices error:", err);
    return new Response(
      JSON.stringify({ error: "Failed to save prices", detail: String(err) }),
      { status: 500, headers: CORS }
    );
  }
};
var config = { path: "/api/set-prices" };
export {
  config,
  set_prices_default as default
};
